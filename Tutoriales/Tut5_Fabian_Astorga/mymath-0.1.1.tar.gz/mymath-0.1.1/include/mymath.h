#ifndef _MATH_H
#define _MATH_H

#define PARAMS 3

int my_add(int a, int b);
int my_sub(int a, int b);
int my_mult(int a, int b);
int my_div(int a, int b);
int my_sqrt(int a);

#endif