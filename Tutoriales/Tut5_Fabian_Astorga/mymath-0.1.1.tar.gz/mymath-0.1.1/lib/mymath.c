#include "../include/mymath.h"

/* SUMA */
int my_add(int a, int b) {
    return (a + b);
}

/* RESTA */
int my_sub(int a, int b) {
    return (a - b);
}

/* MULTIPLICACION */
int my_mult(int a, int b) {
    return (a * b);
}

/* DIVISION */
int my_div(int a, int b) {
    return (a / b);
}

/* RAIZ CUADRADA */
int my_sqrt(int a) {
    return (a * a);
}